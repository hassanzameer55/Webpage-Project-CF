function login(){
    alert( "Sorry\nThere is a server issue\nYou can't login.");
}

function search(){
    
    alert("University not found");
}

function submit(){
    alert("Submited");
}